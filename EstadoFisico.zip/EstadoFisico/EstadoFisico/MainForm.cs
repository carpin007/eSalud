﻿/*
 * Creado por SharpDevelop.
 * Usuario: Carlos Pineda
 * Fecha: 20/10/2018
 * Hora: 04:20 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace EstadoFisico
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Button1Click(object sender, EventArgs e)
		{
			/*var porcentaje = new List<Porcentajedegrasa> //= new Porcentajedegrasa();
			{
				new PorcentajeGrasaMasculino(0,0,0),
				new PorcentajedeGrasaFemenino(0,0,0,0)
			};
			*/
			if (listBox1.SelectedIndex == -1) {
				MessageBox.Show("Debe seleccionar su sexo");
			} else if (listBox1.SelectedIndex == 0) {
				txt_cadera.Enabled = true;
				var Fporcentaje = new PorcentajedeGrasaFemenino(0, 0, 0, 0);
				Fporcentaje.Altura = Convert.ToDouble(txt_altura.Text);
				Fporcentaje.Cintura = Convert.ToDouble(txt_cintura.Text);
				Fporcentaje.Cuello = Convert.ToDouble(txt_cuello.Text);
				Fporcentaje.Cadera = Convert.ToDouble(txt_cadera.Text);
					
				MessageBox.Show("Eres mujer, Tu porcentaje de grasa corporal es :" + Convert.ToString(Fporcentaje.totalizar()));
			} else {
				
				var Mporcentaje = new PorcentajeGrasaMasculino(0, 0, 0);
				Mporcentaje.Altura = Convert.ToDouble(txt_altura.Text);
				Mporcentaje.Cintura = Convert.ToDouble(txt_cintura.Text);
				Mporcentaje.Cuello = Convert.ToDouble(txt_cuello.Text);
				
				MessageBox.Show("Tu porcentaje de grasa corporal es :" + Convert.ToString(Mporcentaje.totalizar()));
			}
			
			
		}
		void ListBox1SelectedIndexChanged(object sender, EventArgs e)
		{
			if (listBox1.SelectedIndex == 0)
				txt_cadera.Enabled = true;
			else
				txt_cadera.Enabled = false;
		}
		
	}
}
