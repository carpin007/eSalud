﻿/*
 * Creado por SharpDevelop.
 * Usuario: Carlos Pineda
 * Fecha: 26/10/2018
 * Hora: 07:24 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace EstadoFisico
{
	/// <summary>
	/// Description of porcentajedegrasa.
	/// </summary>
	public abstract class Porcentajedegrasa
	{
		private double altura;
		private double cintura;
		private double cuello;
		
		public Porcentajedegrasa(double altura, double cintura, double cuello)
		{
			Altura = altura;
			Cintura = cintura;
			Cuello = cuello;
		}
		public double Altura { 
			get{ return altura; }
			set{ altura = value; }
		}
		public double Cintura { 
			get{ return cintura; }
			set{ cintura = value; }
		}
		public double Cuello { 
			get{ return cuello; }
			set{ cuello = value; }
		}
		
		public abstract double totalizar();
		
	}
}
