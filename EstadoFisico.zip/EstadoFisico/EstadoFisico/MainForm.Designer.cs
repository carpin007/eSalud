﻿/*
 * Creado por SharpDevelop.
 * Usuario: Carlos Pineda
 * Fecha: 20/10/2018
 * Hora: 04:20 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace EstadoFisico
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txt_altura;
		private System.Windows.Forms.TextBox txt_cintura;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnCalcular;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txt_cuello;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txt_cadera;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.label1 = new System.Windows.Forms.Label();
			this.txt_altura = new System.Windows.Forms.TextBox();
			this.txt_cintura = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnCalcular = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.txt_cuello = new System.Windows.Forms.TextBox();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.txt_cadera = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(76, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(226, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "Introducir tus datos en el sistema internacional";
			// 
			// txt_altura
			// 
			this.txt_altura.Location = new System.Drawing.Point(168, 98);
			this.txt_altura.Name = "txt_altura";
			this.txt_altura.Size = new System.Drawing.Size(100, 20);
			this.txt_altura.TabIndex = 2;
			// 
			// txt_cintura
			// 
			this.txt_cintura.Location = new System.Drawing.Point(168, 124);
			this.txt_cintura.Name = "txt_cintura";
			this.txt_cintura.Size = new System.Drawing.Size(100, 20);
			this.txt_cintura.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(49, 98);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(120, 23);
			this.label2.TabIndex = 3;
			this.label2.Text = "Altura";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(49, 130);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 4;
			this.label3.Text = "Cintura";
			// 
			// btnCalcular
			// 
			this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCalcular.Location = new System.Drawing.Point(111, 253);
			this.btnCalcular.Name = "btnCalcular";
			this.btnCalcular.Size = new System.Drawing.Size(191, 23);
			this.btnCalcular.TabIndex = 6;
			this.btnCalcular.Text = "Calcular IMC";
			this.btnCalcular.UseVisualStyleBackColor = true;
			this.btnCalcular.Click += new System.EventHandler(this.Button1Click);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(49, 159);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 23);
			this.label4.TabIndex = 6;
			this.label4.Text = "Tu Cuello en (cm)";
			// 
			// txt_cuello
			// 
			this.txt_cuello.Location = new System.Drawing.Point(168, 153);
			this.txt_cuello.Name = "txt_cuello";
			this.txt_cuello.Size = new System.Drawing.Size(100, 20);
			this.txt_cuello.TabIndex = 4;
			// 
			// listBox1
			// 
			this.listBox1.FormattingEnabled = true;
			this.listBox1.Items.AddRange(new object[] {
			"Femenino",
			"Masculino"});
			this.listBox1.Location = new System.Drawing.Point(49, 55);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(120, 30);
			this.listBox1.TabIndex = 1;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(49, 39);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(100, 13);
			this.label5.TabIndex = 9;
			this.label5.Text = "Selecciona tu Sexo";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(49, 182);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(77, 17);
			this.label6.TabIndex = 10;
			this.label6.Text = "Cadera (cm)";
			// 
			// txt_cadera
			// 
			this.txt_cadera.Enabled = false;
			this.txt_cadera.Location = new System.Drawing.Point(168, 179);
			this.txt_cadera.Name = "txt_cadera";
			this.txt_cadera.Size = new System.Drawing.Size(100, 20);
			this.txt_cadera.TabIndex = 5;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(368, 157);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(298, 119);
			this.pictureBox1.TabIndex = 12;
			this.pictureBox1.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(368, 23);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(297, 120);
			this.pictureBox2.TabIndex = 13;
			this.pictureBox2.TabStop = false;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(678, 288);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.txt_cadera);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.txt_cuello);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.btnCalcular);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txt_cintura);
			this.Controls.Add(this.txt_altura);
			this.Controls.Add(this.label1);
			this.Name = "MainForm";
			this.Text = "EstadoFisico";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
