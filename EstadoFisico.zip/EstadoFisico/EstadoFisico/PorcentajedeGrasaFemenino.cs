﻿/*
 * Creado por SharpDevelop.
 * Usuario: Carlos Pineda
 * Fecha: 26/10/2018
 * Hora: 08:05 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace EstadoFisico
{
	/// <summary>
	/// Description of PorcentajedeGrasaFemenino.
	/// </summary>
	public class PorcentajedeGrasaFemenino: Porcentajedegrasa
	{
		private double cadera;
		private double pgc;
		public PorcentajedeGrasaFemenino(double altura, double cintura, double cuello, double cadera)
			: base(altura, cintura, cuello)
		{
			Cadera = cadera;
		}
		/*public PorcentajedeGrasaFemenino(double cadera)
		{
			this.cadera = cadera;
		} */
		public double Cadera { 
			get{ return cadera; }
			set{ cadera = value; }
		}
		
		public override double totalizar()
		{
			pgc = (495 / (1.29579 - (0.35004 * Math.Log10(Cintura + Cadera - Cuello)) + (0.221 * Math.Log10(Altura)))) - 450;
			return pgc;
		}
		
	}
}
