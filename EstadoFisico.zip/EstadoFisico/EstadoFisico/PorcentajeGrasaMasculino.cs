﻿/*
 * Creado por SharpDevelop.
 * Usuario: Carlos Pineda
 * Fecha: 26/10/2018
 * Hora: 09:09 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace EstadoFisico
{
	/// <summary>
	/// Description of PorcentajeGrasaMasculino.
	/// </summary>
	public class PorcentajeGrasaMasculino:Porcentajedegrasa
	{
		private double pgc;
		public PorcentajeGrasaMasculino(double altura, double cintura, double cuello)
			: base(altura, cintura, cuello)
		{
		}
		public override double totalizar()
		{
			
			pgc = (495 / (1.0324 - (0.19077 * Math.Log10(Cintura - Cuello)) + (0.15456 * Math.Log10(Altura)))) - 450;
			return pgc;
		}
		
	}
}
